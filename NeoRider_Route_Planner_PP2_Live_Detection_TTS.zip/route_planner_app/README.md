# route_planner_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.


## PP2 Voice Guidance
This version adds Flutter text-to-speech. A new road-sign guidance message is spoken only when the existing 3-second alert cooldown allows it. The alert card also has a speaker icon to mute/unmute voice guidance.
