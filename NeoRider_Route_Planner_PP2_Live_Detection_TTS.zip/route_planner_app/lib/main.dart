import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:http/http.dart' as http;
import 'package:geolocator/geolocator.dart';
import 'package:camera/camera.dart';
import 'package:flutter_tts/flutter_tts.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Route Planner Pro',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.light,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        fontFamily: 'Poppins',
        useMaterial3: true,
        scaffoldBackgroundColor: Colors.grey[50],
        appBarTheme: AppBarTheme(
          elevation: 0,
          centerTitle: true,
          backgroundColor: Colors.transparent,
          foregroundColor: Colors.blue[800],
          titleTextStyle: TextStyle(
            color: Colors.blue[800],
            fontSize: 22,
            fontWeight: FontWeight.w700,
            letterSpacing: -0.5,
          ),
          iconTheme: IconThemeData(color: Colors.blue[800]),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            padding: EdgeInsets.symmetric(horizontal: 20, vertical: 14),
            textStyle: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.3,
            ),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide.none,
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: Colors.grey[200]!),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: BorderSide(color: Colors.blue, width: 2),
          ),
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          hintStyle: TextStyle(color: Colors.grey[400]),
        ),
        cardTheme: CardThemeData(
          elevation: 8,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
          ),
          shadowColor: Colors.black.withOpacity(0.08),
        ),
      ),
      home: MapScreen(),
    );
  }
}

class MapScreen extends StatefulWidget {
  const MapScreen({super.key});

  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen>
    with SingleTickerProviderStateMixin, WidgetsBindingObserver {
  // Constants
  static const double AVERAGE_SPEED_KMPH = 40.0;
  static const double DEFAULT_ZOOM = 14.0;
  static const double INITIAL_ZOOM = 8.0;
  static const int SEARCH_DEBOUNCE_MS = 500;
  static const int MAX_SEARCH_RESULTS = 10;

  // ============================================================
  // PP2 ROAD-SIGN DETECTION SETTINGS
  // ============================================================
  // The Android phone reaches the FastAPI server through USB ADB reverse:
  // phone 127.0.0.1:8001 -> laptop 127.0.0.1:8001
  static const String FASTAPI_BASE_URL = 'http://127.0.0.1:8001';
  static const Duration DETECTION_INTERVAL = Duration(milliseconds: 1200);
  static const Duration DETECTION_REQUEST_TIMEOUT = Duration(seconds: 8);
  static const Duration ALERT_COOLDOWN = Duration(seconds: 3);
  
  LatLng center = LatLng(7.8731, 80.7718); // Centered on Sri Lanka

  LatLng? startPoint;
  LatLng? endPoint;

  List<LatLng> routePoints = [];
  double distance = 0;
  int estimatedTimeMinutes = 0;
  int bendCount = 0;
  int turnCount = 0;
  DateTime? currentTime;
  DateTime? dropOffTime;

  // Current location tracking
  LatLng? currentLocation;
  bool tripStarted = false;
  StreamSubscription<Position>? positionStream;

  // PP2 live road-camera state
  CameraController? _tripCameraController;
  bool _isCameraInitializing = false;
  String? _cameraError;

  // PP2 FastAPI / YOLO road-sign detection state
  Timer? _detectionTimer;
  bool _isDetectionRequestRunning = false;
  bool _backendConnected = false;
  String _detectionStatus = 'Waiting for trip';
  String? _latestDetectedLabel;
  double? _latestDetectedConfidence;
  String? _latestGuidance;
  DateTime? _latestDetectionTime;
  final Map<String, DateTime> _lastAlertAtByLabel = <String, DateTime>{};
  double _currentSpeedKmh = 0.0;

  // PP2 voice guidance state
  final FlutterTts _flutterTts = FlutterTts();
  bool _voiceGuidanceEnabled = true;

  final MapController mapController = MapController();

  TextEditingController startController = TextEditingController();
  TextEditingController endController = TextEditingController();

  List<dynamic> startSuggestions = [];
  List<dynamic> endSuggestions = [];

  // Debounce timer for search
  Timer? _searchTimer;
  
  // Animation controllers
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _fadeController = AnimationController(
      duration: Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
    _fadeController.forward();

    // Prepare phone text-to-speech for automatic rider alerts.
    _initializeVoiceGuidance();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    positionStream?.cancel();
    _detectionTimer?.cancel();
    _tripCameraController?.dispose();
    _flutterTts.stop();
    _searchTimer?.cancel();
    startController.dispose();
    endController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  // ================= PP2 VOICE GUIDANCE =================
  Future<void> _initializeVoiceGuidance() async {
    try {
      await _flutterTts.setLanguage('en-US');
      await _flutterTts.setSpeechRate(0.48);
      await _flutterTts.setVolume(1.0);
      await _flutterTts.setPitch(1.0);

      // Use navigation-style Android audio attributes so guidance behaves
      // like a short navigation prompt.
      if (Platform.isAndroid) {
        await _flutterTts.setAudioAttributesForNavigation();
      }

      // Do not block the camera/detection loop while speech is playing.
      await _flutterTts.awaitSpeakCompletion(false);

      print('[Voice Guidance] TTS initialized');
    } catch (e) {
      print('[Voice Guidance] Initialization error: $e');
    }
  }

  Future<void> _speakGuidance(String message) async {
    if (!_voiceGuidanceEnabled) return;

    final text = message.trim();
    if (text.isEmpty || text.toLowerCase() == 'no sign detected') return;

    try {
      // Stop an old prompt before speaking a new safety alert.
      await _flutterTts.stop();

      if (Platform.isAndroid) {
        await _flutterTts.speak(text, focus: true);
      } else {
        await _flutterTts.speak(text);
      }

      print('[Voice Guidance] Speaking: $text');
    } catch (e) {
      print('[Voice Guidance] Speak error: $e');
    }
  }

  Future<void> _toggleVoiceGuidance() async {
    final bool enabled = !_voiceGuidanceEnabled;

    if (!enabled) {
      await _flutterTts.stop();
    }

    if (!mounted) return;

    setState(() {
      _voiceGuidanceEnabled = enabled;
    });

    _showSnackBar(
      enabled ? 'Voice guidance enabled' : 'Voice guidance muted',
      isInfo: !enabled,
    );
  }

  // ================= FINAL SMART SEARCH =================
  Future<List<dynamic>> searchPlaces(String query) async {
    List<dynamic> results = [];

    // Search within Sri Lanka's bounding box (west, south, east, north)
    final url =
        "https://nominatim.openstreetmap.org/search"
        "?format=json&limit=20&bounded=1&viewbox=79.5,5.9,81.9,9.8&q=${Uri.encodeComponent(query)}";

    final res = await http.get(
      Uri.parse(url),
      headers: {'User-Agent': 'RoutePlannerPro/2.0'},
    );

    if (res.statusCode == 200) {
      results = json.decode(res.body);
    }

    // Additional search with "Sri Lanka" appended for more results
    if (results.length < 5) {
      final url2 =
          "https://nominatim.openstreetmap.org/search"
          "?format=json&limit=20&q=${Uri.encodeComponent(query)} Sri Lanka";

      final res2 = await http.get(
        Uri.parse(url2),
        headers: {'User-Agent': 'RoutePlannerPro/2.0'},
      );

      if (res2.statusCode == 200) {
        final additionalResults = json.decode(res2.body);
        for (var result in additionalResults) {
          if (result['display_name'].toString().toLowerCase().contains("sri lanka") &&
              !results.any((r) => r['place_id'] == result['place_id'])) {
            results.add(result);
          }
        }
      }
    }

    // Sort by importance and place rank
    results.sort((a, b) {
      double impA = double.tryParse(a['importance'].toString()) ?? 0.0;
      double impB = double.tryParse(b['importance'].toString()) ?? 0.0;
      int rankA = int.tryParse(a['place_rank'].toString()) ?? 30;
      int rankB = int.tryParse(b['place_rank'].toString()) ?? 30;
      
      if (impB != impA) return impB.compareTo(impA);
      return rankA.compareTo(rankB);
    });

    // Limit results
    if (results.length > MAX_SEARCH_RESULTS) {
      results = results.sublist(0, MAX_SEARCH_RESULTS);
    }

    return results;
  }

  // ================= CURRENT LOCATION =================
  Future<void> getCurrentLocation() async {
    try {
      print("[Location] Checking service status...");
      
      bool serviceEnabled = false;
      try {
        serviceEnabled = await Geolocator.isLocationServiceEnabled();
      } catch (e) {
        print("[Location] Error checking service status: $e");
        if (mounted) {
          _showSnackBar("Error checking location service: $e", isError: true);
        }
        return;
      }
      
      if (!serviceEnabled) {
        if (mounted) {
          _showSnackBar("Location services are disabled. Please enable them.", isError: true);
        }
        return;
      }

      print("[Location] Checking permission...");
      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        if (mounted) {
          _showSnackBar("Location permission is required for this feature", isError: true);
        }
        return;
      }

      print("[Location] Getting current position...");
      final position = await Geolocator.getCurrentPosition(
          forceAndroidLocationManager: true,
          timeLimit: Duration(seconds: 15));
      
      final location = LatLng(position.latitude, position.longitude);
      print("[Location] Success: ${location.latitude}, ${location.longitude}");

      if (mounted) {
        setState(() {
          currentLocation = location;
          startPoint = location;
          startController.text = "📍 My Location";
          mapController.move(location, DEFAULT_ZOOM);
        });

        _showSnackBar("Current location set as starting point");
      }
    } catch (e) {
      print("[Location] Error: $e");
      if (mounted) {
        _showSnackBar("Failed to get location: ${e.toString()}", isError: true);
      }
    }
  }

  // ================= PP2 LIVE CAMERA =================
  Future<void> _initializeTripCamera() async {
    if (_isCameraInitializing) return;

    if (mounted) {
      setState(() {
        _isCameraInitializing = true;
        _cameraError = null;
      });
    }

    try {
      final cameras = await availableCameras();

      if (cameras.isEmpty) {
        if (mounted) {
          setState(() {
            _isCameraInitializing = false;
            _cameraError = "No camera was found on this device.";
          });
        }
        return;
      }

      CameraDescription selectedCamera = cameras.first;

      // NeoRider must observe the road, so prefer the rear camera.
      for (final camera in cameras) {
        if (camera.lensDirection == CameraLensDirection.back) {
          selectedCamera = camera;
          break;
        }
      }

      final controller = CameraController(
        selectedCamera,
        ResolutionPreset.high,
        enableAudio: false,
        imageFormatGroup: ImageFormatGroup.jpeg,
      );

      await controller.initialize();

      if (!mounted || !tripStarted) {
        await controller.dispose();
        return;
      }

      await _tripCameraController?.dispose();

      setState(() {
        _tripCameraController = controller;
        _isCameraInitializing = false;
        _cameraError = null;
      });

      // Start near-real-time road-sign inference after the rear camera is ready.
      _startRoadSignDetectionLoop();
    } on CameraException catch (e) {
      if (mounted) {
        setState(() {
          _isCameraInitializing = false;
          _cameraError =
              "Camera error: ${e.code}${e.description != null ? ' - ${e.description}' : ''}";
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isCameraInitializing = false;
          _cameraError = "Unable to start camera: $e";
        });
      }
    }
  }

  // ================= PP2 FASTAPI + YOLO DETECTION =================
  void _startRoadSignDetectionLoop() {
    _detectionTimer?.cancel();

    if (!tripStarted) return;

    if (mounted) {
      setState(() {
        _detectionStatus = 'Scanning road signs...';
      });
    }

    // Run the first scan quickly, then continue at a safe interval.
    Future<void>.delayed(const Duration(milliseconds: 350), () {
      if (tripStarted) {
        _captureAndPredictRoadSign();
      }
    });

    _detectionTimer = Timer.periodic(DETECTION_INTERVAL, (_) {
      _captureAndPredictRoadSign();
    });
  }

  void _stopRoadSignDetectionLoop({bool clearResult = true}) {
    _detectionTimer?.cancel();
    _detectionTimer = null;
    _isDetectionRequestRunning = false;

    if (mounted && clearResult) {
      setState(() {
        _backendConnected = false;
        _detectionStatus = 'Waiting for trip';
        _latestDetectedLabel = null;
        _latestDetectedConfidence = null;
        _latestGuidance = null;
        _latestDetectionTime = null;
        _lastAlertAtByLabel.clear();
        _currentSpeedKmh = 0.0;
      });
    }
  }

  Future<void> _captureAndPredictRoadSign() async {
    if (!tripStarted || _isDetectionRequestRunning) return;

    final controller = _tripCameraController;

    if (controller == null || !controller.value.isInitialized) {
      return;
    }

    XFile? capturedImage;

    _isDetectionRequestRunning = true;

    try {
      capturedImage = await controller.takePicture();

      final request = http.MultipartRequest(
        'POST',
        Uri.parse('$FASTAPI_BASE_URL/predict'),
      );

      request.fields['speed_kmh'] = _currentSpeedKmh.toStringAsFixed(1);
      request.files.add(
        await http.MultipartFile.fromPath(
          'file',
          capturedImage.path,
          filename: 'neorider_live_frame.jpg',
        ),
      );

      final streamedResponse = await request.send().timeout(
            DETECTION_REQUEST_TIMEOUT,
          );

      final response = await http.Response.fromStream(streamedResponse);

      if (!mounted || !tripStarted) return;

      if (response.statusCode != 200) {
        setState(() {
          _backendConnected = false;
          _detectionStatus = 'FastAPI error ${response.statusCode}';
        });
        return;
      }

      final dynamic decoded = json.decode(response.body);

      if (decoded is! Map<String, dynamic>) {
        setState(() {
          _backendConnected = false;
          _detectionStatus = 'Invalid FastAPI response';
        });
        return;
      }

      final int detectionCount =
          (decoded['detection_count'] as num?)?.toInt() ?? 0;
      final String? label = decoded['primary_label']?.toString();
      final double? confidence =
          (decoded['primary_confidence'] as num?)?.toDouble();
      final String guidance =
          decoded['primary_guidance']?.toString() ?? 'No sign detected';

      bool shouldSpeakGuidance = false;

      setState(() {
        _backendConnected = true;

        if (detectionCount > 0 && label != null && label.isNotEmpty) {
          final now = DateTime.now();
          final previousAlertTime = _lastAlertAtByLabel[label];
          final bool cooldownPassed = previousAlertTime == null ||
              now.difference(previousAlertTime) >= ALERT_COOLDOWN;

          if (cooldownPassed) {
            _lastAlertAtByLabel[label] = now;
            _detectionStatus = 'Guidance alert';
            shouldSpeakGuidance = true;
          } else {
            _detectionStatus = 'Detected - cooldown active';
          }

          _latestDetectedLabel = label;
          _latestDetectedConfidence = confidence;
          _latestGuidance = guidance;
          _latestDetectionTime = now;
        } else {
          _detectionStatus = 'Scanning road signs...';
          _latestDetectedLabel = null;
          _latestDetectedConfidence = null;
          _latestGuidance = null;
          _latestDetectionTime = null;
        }
      });

      // Speak only when the same cooldown rule allows a new rider alert.
      if (shouldSpeakGuidance) {
        unawaited(_speakGuidance(guidance));
      }
    } on TimeoutException {
      if (mounted && tripStarted) {
        setState(() {
          _backendConnected = false;
          _detectionStatus = 'FastAPI timeout';
        });
      }
    } on SocketException catch (e) {
      print('[Road Sign Detection] Network error: $e');
      if (mounted && tripStarted) {
        setState(() {
          _backendConnected = false;
          _detectionStatus = 'FastAPI not connected';
        });
      }
    } on CameraException catch (e) {
      print('[Road Sign Detection] Camera error: ${e.code} ${e.description}');
      if (mounted && tripStarted) {
        setState(() {
          _detectionStatus = 'Camera capture error';
        });
      }
    } catch (e) {
      print('[Road Sign Detection] Error: $e');
      if (mounted && tripStarted) {
        setState(() {
          _detectionStatus = 'Detection error';
        });
      }
    } finally {
      _isDetectionRequestRunning = false;

      if (capturedImage != null) {
        try {
          final file = File(capturedImage.path);
          if (await file.exists()) {
            await file.delete();
          }
        } catch (e) {
          print('[Road Sign Detection] Temporary image cleanup error: $e');
        }
      }
    }
  }

  Future<void> _disposeTripCamera() async {
    _stopRoadSignDetectionLoop(clearResult: false);

    final controller = _tripCameraController;
    _tripCameraController = null;

    if (controller != null) {
      try {
        await controller.dispose();
      } catch (e) {
        print("[Camera] Dispose error: $e");
      }
    }

    if (mounted) {
      setState(() {
        _isCameraInitializing = false;
        _cameraError = null;
      });
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    final controller = _tripCameraController;

    if (state == AppLifecycleState.inactive ||
        state == AppLifecycleState.paused) {
      _detectionTimer?.cancel();
      _detectionTimer = null;
      if (controller != null) {
        controller.dispose();
        _tripCameraController = null;
      }
    } else if (state == AppLifecycleState.resumed && tripStarted) {
      _initializeTripCamera();
    }
  }

  // ================= TRIP TRACKING =================
  Future<void> startTrip() async {
    if (startPoint == null || endPoint == null) {
      _showSnackBar("Please set both start and end locations before starting trip", isError: true);
      return;
    }

    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        _showSnackBar("Location services are disabled. Please enable them.", isError: true);
        return;
      }

      LocationPermission permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        _showSnackBar("Location permission denied. Please grant permission to track trip.", isError: true);
        return;
      }

      setState(() {
        tripStarted = true;
      });

      // PP2: start the rear road camera when the trip starts.
      await _initializeTripCamera();

      const LocationSettings locationSettings = LocationSettings(
        accuracy: LocationAccuracy.high,
        distanceFilter: 10,
      );

      positionStream = Geolocator.getPositionStream(
        locationSettings: locationSettings,
      ).listen((Position position) {
        if (mounted) {
          setState(() {
            currentLocation = LatLng(position.latitude, position.longitude);

            // Position.speed is metres/second. Convert it to km/h for
            // the context-aware FastAPI guidance logic.
            final double measuredSpeedKmh = position.speed * 3.6;
            _currentSpeedKmh = measuredSpeedKmh.isFinite && measuredSpeedKmh > 0
                ? measuredSpeedKmh
                : 0.0;

            mapController.move(currentLocation!, DEFAULT_ZOOM);
          });
        }
      }, onError: (e) {
        print("[Trip Tracking] Error: $e");
        if (mounted) {
          _showSnackBar("Location tracking encountered an error", isError: true);
        }
      });

      _showSnackBar("Trip tracking started. Follow your journey on the map.");
    } catch (e) {
      print("[Trip Tracking] Start error: $e");
      if (mounted) {
        _showSnackBar("Failed to start trip tracking", isError: true);
      }
    }
  }

  Future<void> stopTrip() async {
    await positionStream?.cancel();
    positionStream = null;

    await _disposeTripCamera();
    await _flutterTts.stop();

    if (!mounted) return;

    setState(() {
      tripStarted = false;
      currentLocation = null;
      startPoint = null;
      endPoint = null;
      startController.clear();
      endController.clear();
      routePoints.clear();
      distance = 0;
      estimatedTimeMinutes = 0;
      bendCount = 0;
      turnCount = 0;
      currentTime = null;
      dropOffTime = null;

      // Clear PP2 road-sign detection state.
      _backendConnected = false;
      _detectionStatus = 'Waiting for trip';
      _latestDetectedLabel = null;
      _latestDetectedConfidence = null;
      _latestGuidance = null;
      _latestDetectionTime = null;
      _lastAlertAtByLabel.clear();
      _currentSpeedKmh = 0.0;
    });

    _showSnackBar("Trip completed. Route information has been cleared.");
  }

  void onSearchChanged(String value, bool isStart) {
    _searchTimer?.cancel();
    
    if (value.length < 2) {
      setState(() {
        if (isStart) {
          startSuggestions.clear();
        } else {
          endSuggestions.clear();
        }
      });
      return;
    }

    _searchTimer = Timer(Duration(milliseconds: SEARCH_DEBOUNCE_MS), () async {
      try {
        final results = await searchPlaces(value);
        setState(() {
          if (isStart) {
            startSuggestions = results;
          } else {
            endSuggestions = results;
          }
        });
      } catch (e) {
        print("[Search] Error: $e");
        setState(() {
          if (isStart) {
            startSuggestions.clear();
          } else {
            endSuggestions.clear();
          }
        });
      }
    });
  }

  // ================= DISPLAY HELPERS =================
  String _getDisplayName(dynamic place) {
    final name = place['name'] ?? 'Unknown';
    return name.isNotEmpty ? name : 'Unnamed Location';
  }

  String _getDisplayType(dynamic place) {
    final type = place['type'] ?? '';
    final addresstype = place['addresstype'] ?? '';
    
    if (type.isNotEmpty && addresstype.isNotEmpty) {
      return '$addresstype ($type)';
    } else if (addresstype.isNotEmpty) {
      return addresstype;
    } else if (type.isNotEmpty) {
      return type;
    }
    return 'Location';
  }
  
  // ================= BEND CALCULATION =================
  // Sri Lanka optimized: Detects road bends, U-turns, and curves
  int calculateBends(List<LatLng> points) {
    if (points.length < 3) return 0;
    
    int bends = 0;
    const double bentThreshold = 25.0; // Sri Lankan roads: 25° for regular curves (tea plantations, coastal roads)
    
    for (int i = 1; i < points.length - 1; i++) {
      // Get three consecutive points
      LatLng p1 = points[i - 1];
      LatLng p2 = points[i];
      LatLng p3 = points[i + 1];
      
      // Calculate bearing (direction) from p1 to p2
      double bearing1 = _calculateBearing(p1, p2);
      // Calculate bearing from p2 to p3
      double bearing2 = _calculateBearing(p2, p3);
      
      // Calculate the angle difference
      double angleDiff = (bearing2 - bearing1).abs();
      // Normalize to 0-180 range
      if (angleDiff > 180) {
        angleDiff = 360 - angleDiff;
      }
      
      // Sri Lanka classified bends:
      // 25-40°: Regular bends (Kandy hill roads, plantations)
      // 40-60°: Significant bends (N and U shaped curves, hairpins)
      // Count all significant direction changes as bends
      if (angleDiff >= bentThreshold) {
        bends++;
      }
    }
    
    return bends;
  }

  // ================= TURN CALCULATION =================
  // Sri Lanka optimized: Detects sharp intersection turns, roundabouts, hairpins
  int calculateTurns(List<LatLng> points) {
    if (points.length < 3) return 0;
    
    int turns = 0;
    const double turnThreshold = 45.0; // Sri Lankan roads: 45° for sharp turns (intersections, roundabouts, hairpins)
    
    for (int i = 1; i < points.length - 1; i++) {
      // Get three consecutive points
      LatLng p1 = points[i - 1];
      LatLng p2 = points[i];
      LatLng p3 = points[i + 1];
      
      // Calculate bearing (direction) from p1 to p2
      double bearing1 = _calculateBearing(p1, p2);
      // Calculate bearing from p2 to p3
      double bearing2 = _calculateBearing(p2, p3);
      
      // Calculate the angle difference
      double angleDiff = (bearing2 - bearing1).abs();
      // Normalize to 0-180 range
      if (angleDiff > 180) {
        angleDiff = 360 - angleDiff;
      }
      
      // Sri Lanka sharp turns:
      // 45-60°: Significant direction changes (sharp curves, U-turns)
      // 60°+: Very sharp intersection turns (Colombo traffic, mountain hairpins)
      // Count sharp direction changes requiring careful steering
      if (angleDiff >= turnThreshold) {
        turns++;
      }
    }
    
    return turns;
  }

  double _calculateBearing(LatLng from, LatLng to) {
    final fromLat = from.latitude * pi / 180.0;
    final fromLon = from.longitude * pi / 180.0;
    final toLat = to.latitude * pi / 180.0;
    final toLon = to.longitude * pi / 180.0;
    
    final dLon = toLon - fromLon;
    
    final y = sin(dLon) * cos(toLat);
    final x = cos(fromLat) * sin(toLat) - sin(fromLat) * cos(toLat) * cos(dLon);
    
    double bearing = (atan2(y, x) * 180.0 / pi + 360) % 360;
    return bearing;
  }

  // ================= TIME FORMATTING =================
  String formatTime(DateTime time) {
    return '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';
  }
  
  // ================= SELECT =================
  void selectLocation(dynamic place, bool isStart) {
    final lat = double.parse(place['lat']);
    final lon = double.parse(place['lon']);
    final latLng = LatLng(lat, lon);
    final name = _getDisplayName(place);
    final type = _getDisplayType(place);

    setState(() {
      routePoints.clear();
      distance = 0;
      estimatedTimeMinutes = 0;
      bendCount = 0;
      turnCount = 0;

      if (isStart) {
        startPoint = latLng;
        startController.text = name;
        startSuggestions.clear();
        _showSnackBar("Start location set to: $name ($type)");
      } else {
        endPoint = latLng;
        endController.text = name;
        endSuggestions.clear();
        _showSnackBar("Destination set to: $name ($type)");
      }

      mapController.move(latLng, DEFAULT_ZOOM);
    });
  }

  // ================= ROUTE =================
  Future<void> getRoute() async {
    _showSnackBar("Calculating route...", isInfo: true);
    
    try {
      if (startPoint == null && startController.text.isNotEmpty) {
        final results = await searchPlaces(startController.text);
        if (results.isNotEmpty) {
          final lat = double.parse(results[0]['lat']);
          final lon = double.parse(results[0]['lon']);
          startPoint = LatLng(lat, lon);
        }
      }

      if (endPoint == null && endController.text.isNotEmpty) {
        final results = await searchPlaces(endController.text);
        if (results.isNotEmpty) {
          final lat = double.parse(results[0]['lat']);
          final lon = double.parse(results[0]['lon']);
          endPoint = LatLng(lat, lon);
        }
      }

      if (startPoint == null || endPoint == null) {
        _showSnackBar("Could not find specified locations. Please check your input.", isError: true);
        return;
      }

      final url =
          "https://router.project-osrm.org/route/v1/driving/"
          "${startPoint!.longitude},${startPoint!.latitude};"
          "${endPoint!.longitude},${endPoint!.latitude}"
          "?overview=full&geometries=geojson";

      final res = await http.get(Uri.parse(url));
      final data = json.decode(res.body);

      if (data['routes'] == null || data['routes'].isEmpty) {
        _showSnackBar("No route found between these locations", isError: true);
        return;
      }

      final coords = data['routes'][0]['geometry']['coordinates'];

      setState(() {
        routePoints = coords.map<LatLng>((c) => LatLng(c[1], c[0])).toList();
        distance = data['routes'][0]['distance'] / 1000;
        estimatedTimeMinutes = ((distance / AVERAGE_SPEED_KMPH) * 60).toInt();
        
        // Calculate bends and turns in the route
        bendCount = calculateBends(routePoints);
        turnCount = calculateTurns(routePoints);
        
        // Set current time and drop-off time
        currentTime = DateTime.now();
        dropOffTime = currentTime!.add(Duration(minutes: estimatedTimeMinutes));

        if (routePoints.isNotEmpty) {
          mapController.fitCamera(
            CameraFit.bounds(
              bounds: LatLngBounds.fromPoints(routePoints), 
              padding: EdgeInsets.all(50)
            ),
          );
        }
      });

      _showSnackBar("Route calculated successfully! Distance: ${distance.toStringAsFixed(2)} km");
    } catch (e) {
      print("[Route] ERROR: $e");
      _showSnackBar("Failed to calculate route. Please try again.", isError: true);
    }
  }

  // ================= HELPER METHODS =================
  void _showSnackBar(String message, {bool isError = false, bool isInfo = false}) {
    if (!mounted) return;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(
              isError ? Icons.error_outline : (isInfo ? Icons.info_outline : Icons.check_circle_outline),
              color: Colors.white,
              size: 20,
            ),
            SizedBox(width: 12),
            Expanded(child: Text(message, style: TextStyle(fontWeight: FontWeight.w500))),
          ],
        ),
        backgroundColor: isError ? Colors.red[600] : (isInfo ? Colors.blue[600] : Colors.green[600]),
        behavior: SnackBarBehavior.floating,
        duration: Duration(seconds: isError ? 4 : 2),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        margin: EdgeInsets.all(16),
      ),
    );
  }

  String _formatETA() {
    if (estimatedTimeMinutes <= 0) return '';
    final hours = estimatedTimeMinutes ~/ 60;
    final minutes = estimatedTimeMinutes % 60;
    
    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }
    return '${minutes}m';
  }

  // ================= UI =================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.route, size: 24),
            SizedBox(width: 8),
            Text("Neo Rider"),
          ],
        ),
        elevation: 0,
        backgroundColor: Colors.transparent,
        actions: [
          if (routePoints.isNotEmpty && !tripStarted)
            Container(
              margin: EdgeInsets.only(right: 8),
              child: IconButton(
                icon: Icon(Icons.clear_all),
                onPressed: () {
                  setState(() {
                    routePoints.clear();
                    distance = 0;
                    estimatedTimeMinutes = 0;
                  });
                  _showSnackBar("Route cleared");
                },
                tooltip: "Clear Route",
              ),
            ),
        ],
      ),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Stack(
          children: [
            FlutterMap(
              mapController: mapController,
              options: MapOptions(
                initialCenter: center,
                initialZoom: INITIAL_ZOOM,
              ),
              children: [
                TileLayer(
                  urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
                  userAgentPackageName: 'com.example.route_planner_pro',
                ),

                MarkerLayer(
                  markers: [
                    if (currentLocation != null && tripStarted)
                      Marker(
                        point: currentLocation!,
                        width: 50,
                        height: 50,
                        child: AnimatedContainer(
                          duration: Duration(milliseconds: 300),
                          decoration: BoxDecoration(
                            color: Colors.blue,
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white, width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.blue.withOpacity(0.5),
                                blurRadius: 12,
                                spreadRadius: 4,
                              )
                            ],
                          ),
                          child: Icon(Icons.my_location, color: Colors.white, size: 22),
                        ),
                      ),
                    if (startPoint != null && !tripStarted)
                      Marker(
                        point: startPoint!,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.green[600],
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))
                                ],
                              ),
                              child: Icon(Icons.flag, color: Colors.white, size: 24),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 4),
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: Colors.green[600],
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(color: Colors.black26, blurRadius: 2)
                                ],
                              ),
                              child: Text('START',
                                  style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                      ),
                    if (endPoint != null && !tripStarted)
                      Marker(
                        point: endPoint!,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Container(
                              padding: EdgeInsets.all(6),
                              decoration: BoxDecoration(
                                color: Colors.red[600],
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(0, 2))
                                ],
                              ),
                              child: Icon(Icons.flag, color: Colors.white, size: 24),
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 4),
                              padding: EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: Colors.red[600],
                                borderRadius: BorderRadius.circular(12),
                                boxShadow: [
                                  BoxShadow(color: Colors.black26, blurRadius: 2)
                                ],
                              ),
                              child: Text('DEST',
                                  style: TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                            ),
                          ],
                        ),
                      ),
                  ],
                ),

                PolylineLayer(
                  polylines: [
                    if (routePoints.isNotEmpty)
                      Polyline(
                        points: routePoints,
                        strokeWidth: 5,
                        color: Colors.blue.withOpacity(0.85),
                        isDotted: false,
                      ),
                  ],
                ),
              ],
            ),

            // PP2 - camera status and live rear-camera preview during a trip
            if (tripStarted)
              Positioned(
                top: 16,
                left: 16,
                child: _buildCameraStatusChip(),
              ),

            if (tripStarted)
              Positioned(
                top: 16,
                right: 16,
                child: _buildTripCameraPanel(),
              ),

            // PP2 - current YOLO/FastAPI road-sign result.
            if (tripStarted)
              Positioned(
                top: 235,
                left: 16,
                right: 16,
                child: _buildRoadSignDetectionPanel(),
              ),

            // Route Info Card (when route is calculated)
            if (routePoints.isNotEmpty && !tripStarted)
              AnimatedPositioned(
                duration: Duration(milliseconds: 400),
                curve: Curves.easeOutCubic,
                top: 20,
                left: 20,
                right: 20,
                child: Container(
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 232, 230, 230).withOpacity(0.85),
                    borderRadius: BorderRadius.circular(24),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.12),
                        blurRadius: 20,
                        offset: Offset(0, 8),
                      ),
                    ],
                  ),
                  child: Material(
                    color: Colors.transparent,
                    child: Padding(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Container(
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [Colors.blue[600]!, Colors.blue[400]!],
                                  ),
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Icon(Icons.route, color: Colors.white, size: 20),
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: Text(
                                  "Route Details",
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.w700,
                                    color: Colors.grey[800],
                                  ),
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                                decoration: BoxDecoration(
                                  color: Colors.blue[50],
                                  borderRadius: BorderRadius.circular(20),
                                ),
                                child: Text(
                                  "${distance.toStringAsFixed(1)} km",
                                  style: TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.blue[700],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: _buildInfoChip(
                                  icon: Icons.access_time,
                                  label: "Est. Time",
                                  value: _formatETA(),
                                  color: const Color.fromARGB(255, 67, 176, 71),
                                ),
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: _buildInfoChip(
                                  icon: Icons.turn_right,
                                  label: "Bends",
                                  value: "$bendCount",
                                  color: const Color.fromARGB(255, 243, 147, 4),
                                ),
                              ),
                              SizedBox(width: 12),
                              Expanded(
                                child: _buildInfoChip(
                                  icon: Icons.shuffle,
                                  label: "Turns",
                                  value: "$turnCount",
                                  color: Colors.red,
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: _buildInfoChip(
                                  icon: Icons.speed,
                                  label: "Avg Speed",
                                  value: "$AVERAGE_SPEED_KMPH km/h",
                                  color: const Color.fromARGB(255, 147, 29, 168),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 16),
                          Divider(height: 1),
                          SizedBox(height: 16),
                          Row(
                            children: [
                              Expanded(
                                child: _buildTimeInfo(
                                  icon: Icons.departure_board,
                                  label: "Departure",
                                  time: currentTime,
                                  color: const Color.fromARGB(255, 29, 136, 223),
                                ),
                              ),
                              Expanded(
                                child: _buildTimeInfo(
                                  icon: Icons.location_on,
                                  label: "Arrival",
                                  time: dropOffTime,
                                  color: const Color.fromARGB(255, 222, 53, 41),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            width: double.infinity,
                            child: ElevatedButton.icon(
                              onPressed: startTrip,
                              icon: Icon(Icons.play_arrow, size: 22),
                              label: Text(
                                "START TRIP",
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
                              ),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green[600],
                                foregroundColor: Colors.white,
                                padding: EdgeInsets.symmetric(vertical: 16),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

            // Search Panel (when no trip active)
            if (!tripStarted && routePoints.isEmpty)
              AnimatedPositioned(
                duration: Duration(milliseconds: 400),
                curve: Curves.easeOutCubic,
                top: 20,
                left: 20,
                right: 20,
                child: Container(
                  constraints: BoxConstraints(maxHeight: MediaQuery.of(context).size.height * 0.8),
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(255, 232, 230, 230).withOpacity(0.65),
                    borderRadius: BorderRadius.circular(28),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.15),
                        blurRadius: 30,
                        offset: Offset(0, 10),
                      ),
                    ],
                  ),
                  child: SingleChildScrollView(
                    child: Padding(
                      padding: EdgeInsets.all(24),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Container(
                            width: 60,
                            height: 4,
                            decoration: BoxDecoration(
                              color: Colors.grey[300],
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                          SizedBox(height: 20),
                          Icon(Icons.route, size: 48, color: const Color.fromARGB(255, 23, 112, 190)),
                          SizedBox(height: 12),
                          Text(
                            "Plan Your Journey",
                            style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w800,
                              color: Colors.grey[800],
                              letterSpacing: -0.5,
                            ),
                          ),
                          SizedBox(height: 8),
                          Text(
                            "Enter your start point and destination",
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey[600],
                            ),
                          ),
                          SizedBox(height: 24),

                          // Start Location Field
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.grey[50],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(left: 16, top: 12, bottom: 4),
                                  child: Row(
                                    children: [
                                      Icon(Icons.circle, size: 8, color: const Color.fromARGB(255, 56, 170, 60)),
                                      SizedBox(width: 6),
                                      Text("Starting Point",
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.green[700],
                                            letterSpacing: 0.5,
                                          )),
                                    ],
                                  ),
                                ),
                                TextField(
                                  controller: startController,
                                  decoration: InputDecoration(
                                    hintText: "Search for a location...",
                                    border: InputBorder.none,
                                    prefixIcon: Icon(Icons.location_on, color: const Color.fromARGB(255, 49, 146, 54), size: 22),
                                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                                  ),
                                  onChanged: (v) {
                                    startPoint = null;
                                    onSearchChanged(v, true);
                                  },
                                ),
                              ],
                            ),
                          ),

                          if (startSuggestions.isNotEmpty)
                            Container(
                              margin: EdgeInsets.only(top: 8),
                              constraints: BoxConstraints(maxHeight: 200),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Colors.grey[200]!),
                              ),
                              child: ListView.separated(
                                shrinkWrap: true,
                                itemCount: startSuggestions.length,
                                separatorBuilder: (_, _) => Divider(height: 1, indent: 16),
                                itemBuilder: (ctx, idx) => ListTile(
                                  dense: true,
                                  leading: CircleAvatar(
                                    radius: 16,
                                    backgroundColor: Colors.green[100],
                                    child: Icon(Icons.place, size: 16, color: Colors.green[700]),
                                  ),
                                  title: Text(_getDisplayName(startSuggestions[idx]),
                                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                                  subtitle: Text(_getDisplayType(startSuggestions[idx]),
                                      style: TextStyle(fontSize: 11, color: Colors.grey[600])),
                                  onTap: () => selectLocation(startSuggestions[idx], true),
                                ),
                              ),
                            ),

                          SizedBox(height: 16),

                          // Destination Field
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(20),
                              color: Colors.grey[50],
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: EdgeInsets.only(left: 16, top: 12, bottom: 4),
                                  child: Row(
                                    children: [
                                      Icon(Icons.flag, size: 8, color: Colors.red),
                                      SizedBox(width: 6),
                                      Text("Destination",
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w600,
                                            color: Colors.red[700],
                                            letterSpacing: 0.5,
                                          )),
                                    ],
                                  ),
                                ),
                                TextField(
                                  controller: endController,
                                  decoration: InputDecoration(
                                    hintText: "Search for a location...",
                                    border: InputBorder.none,
                                    prefixIcon: Icon(Icons.location_on, color: Colors.red[600], size: 22),
                                    contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
                                  ),
                                  onChanged: (v) {
                                    endPoint = null;
                                    onSearchChanged(v, false);
                                  },
                                ),
                              ],
                            ),
                          ),

                          if (endSuggestions.isNotEmpty)
                            Container(
                              margin: EdgeInsets.only(top: 8),
                              constraints: BoxConstraints(maxHeight: 200),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                                border: Border.all(color: Colors.grey[200]!),
                              ),
                              child: ListView.separated(
                                shrinkWrap: true,
                                itemCount: endSuggestions.length,
                                separatorBuilder: (_, _) => Divider(height: 1, indent: 16),
                                itemBuilder: (ctx, idx) => ListTile(
                                  dense: true,
                                  leading: CircleAvatar(
                                    radius: 16,
                                    backgroundColor: const Color.fromARGB(255, 247, 197, 202),
                                    child: Icon(Icons.place, size: 16, color: Colors.red[700]),
                                  ),
                                  title: Text(_getDisplayName(endSuggestions[idx]),
                                      style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                                  subtitle: Text(_getDisplayType(endSuggestions[idx]),
                                      style: TextStyle(fontSize: 11, color: Colors.grey[600])),
                                  onTap: () => selectLocation(endSuggestions[idx], false),
                                ),
                              ),
                            ),

                          SizedBox(height: 24),

                          // Action Buttons
                          Column(
                            children: [
                              // My Location Button
                              Container(
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [const Color.fromARGB(255, 230, 129, 5), Colors.amber[500]!],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.orange[600]!.withOpacity(0.3),
                                      blurRadius: 12,
                                      offset: Offset(0, 6),
                                    ),
                                  ],
                                ),
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    onTap: getCurrentLocation,
                                    borderRadius: BorderRadius.circular(16),
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(vertical: 14),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.my_location, size: 22, color: Colors.white),
                                          SizedBox(width: 8),
                                          Text(
                                            "My Location",
                                            style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white,
                                              letterSpacing: 0.3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(height: 16),
                              
                              // Calculate Route Button
                              Container(
                                width: double.infinity,
                                decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [Colors.blue[600]!, Colors.blue[500]!],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                                  borderRadius: BorderRadius.circular(16),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.blue[600]!.withOpacity(0.3),
                                      blurRadius: 12,
                                      offset: Offset(0, 6),
                                    ),
                                  ],
                                ),
                                child: Material(
                                  color: Colors.transparent,
                                  child: InkWell(
                                    onTap: getRoute,
                                    borderRadius: BorderRadius.circular(16),
                                    child: Padding(
                                      padding: EdgeInsets.symmetric(vertical: 14),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.route, size: 22, color: Colors.white),
                                          SizedBox(width: 8),
                                          Text(
                                            "Calculate Route",
                                            style: TextStyle(
                                              fontSize: 15,
                                              fontWeight: FontWeight.w700,
                                              color: Colors.white,
                                              letterSpacing: 0.3,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

            // Stop Trip Button
            if (tripStarted)
              AnimatedPositioned(
                duration: Duration(milliseconds: 400),
                curve: Curves.easeOutCubic,
                bottom: 30,
                left: 20,
                right: 20,
                child: SafeArea(
                  child: ElevatedButton.icon(
                    onPressed: stopTrip,
                    icon: Icon(Icons.stop_circle, size: 28),
                    label: Text(
                      "STOP TRIP",
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red[600],
                      foregroundColor: Colors.white,
                      padding: EdgeInsets.symmetric(vertical: 18),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 8,
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
  
  Widget _buildCameraStatusChip() {
    final bool cameraReady = _tripCameraController != null &&
        _tripCameraController!.value.isInitialized &&
        _cameraError == null;

    final Color statusColor;
    final String statusText;
    final IconData statusIcon;

    if (_cameraError != null) {
      statusColor = Colors.red;
      statusText = "Camera Error";
      statusIcon = Icons.videocam_off;
    } else if (_isCameraInitializing || !cameraReady) {
      statusColor = Colors.orange;
      statusText = "Starting Camera";
      statusIcon = Icons.hourglass_top;
    } else {
      statusColor = Colors.green;
      statusText = "Camera Active";
      statusIcon = Icons.videocam;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.95),
        borderRadius: BorderRadius.circular(14),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.16),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(statusIcon, color: statusColor, size: 18),
          SizedBox(width: 7),
          Text(
            statusText,
            style: TextStyle(
              color: Colors.grey[900],
              fontSize: 12,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTripCameraPanel() {
    final controller = _tripCameraController;
    final bool cameraReady = controller != null &&
        controller.value.isInitialized &&
        _cameraError == null;

    return Container(
      width: 155,
      height: 205,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: Colors.white, width: 3),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.28),
            blurRadius: 14,
            offset: Offset(0, 6),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(15),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (cameraReady)
              CameraPreview(controller)
            else
              Container(
                color: Colors.black87,
                alignment: Alignment.center,
                padding: EdgeInsets.all(12),
                child: _cameraError != null
                    ? Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.videocam_off, color: Colors.redAccent, size: 34),
                          SizedBox(height: 8),
                          Text(
                            "Camera unavailable",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 11,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                          SizedBox(height: 8),
                          GestureDetector(
                            onTap: _initializeTripCamera,
                            child: Container(
                              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                              decoration: BoxDecoration(
                                color: Colors.blue[600],
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                "RETRY",
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ],
                      )
                    : Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          SizedBox(
                            width: 24,
                            height: 24,
                            child: CircularProgressIndicator(
                              strokeWidth: 2.5,
                              color: Colors.white,
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(
                            "Starting rear camera...",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 10,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
              ),

            Positioned(
              top: 8,
              right: 8,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: cameraReady ? Colors.red[600] : Colors.grey[700],
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                    ),
                    SizedBox(width: 5),
                    Text(
                      cameraReady ? "LIVE" : "WAIT",
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 9,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),

            Positioned(
              left: 8,
              right: 8,
              bottom: 8,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 5),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.65),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  "Road Sign Camera",
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 9,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRoadSignDetectionPanel() {
    final bool hasDetection = _latestDetectedLabel != null;

    final Color accentColor;
    final IconData leadingIcon;

    if (hasDetection) {
      accentColor = Colors.blue[700]!;
      leadingIcon = Icons.warning_amber_rounded;
    } else if (!_backendConnected && _detectionStatus.contains('FastAPI')) {
      accentColor = Colors.red[700]!;
      leadingIcon = Icons.cloud_off;
    } else {
      accentColor = Colors.green[700]!;
      leadingIcon = Icons.radar;
    }

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.96),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: accentColor.withOpacity(0.35),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.16),
            blurRadius: 12,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: accentColor.withOpacity(0.12),
              shape: BoxShape.circle,
            ),
            child: Icon(
              leadingIcon,
              color: accentColor,
              size: 22,
            ),
          ),
          SizedBox(width: 11),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (hasDetection) ...[
                  Text(
                    'Detected: $_latestDetectedLabel',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.grey[900],
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    _latestDetectedConfidence == null
                        ? 'Confidence: unavailable'
                        : 'Confidence: ${(_latestDetectedConfidence! * 100).toStringAsFixed(1)}%',
                    style: TextStyle(
                      color: accentColor,
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    _latestGuidance ?? '',
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      color: Colors.grey[800],
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ] else ...[
                  Text(
                    _detectionStatus,
                    style: TextStyle(
                      color: Colors.grey[900],
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  SizedBox(height: 5),
                  Text(
                    _backendConnected
                        ? 'FastAPI connected • Speed ${_currentSpeedKmh.toStringAsFixed(1)} km/h'
                        : 'Waiting for FastAPI • Speed ${_currentSpeedKmh.toStringAsFixed(1)} km/h',
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontSize: 10,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
                if (_latestDetectionTime != null) ...[
                  SizedBox(height: 4),
                  Text(
                    '${_detectionStatus} • ${_currentSpeedKmh.toStringAsFixed(1)} km/h',
                    style: TextStyle(
                      color: Colors.grey[500],
                      fontSize: 9,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ],
            ),
          ),
          SizedBox(width: 4),
          IconButton(
            onPressed: _toggleVoiceGuidance,
            tooltip: _voiceGuidanceEnabled
                ? 'Mute voice guidance'
                : 'Enable voice guidance',
            icon: Icon(
              _voiceGuidanceEnabled ? Icons.volume_up : Icons.volume_off,
              color: _voiceGuidanceEnabled ? Colors.green[700] : Colors.grey[500],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoChip({required IconData icon, required String label, required String value, required Color color}) {
    return Container(
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        children: [
          Icon(icon, size: 20, color: color),
          SizedBox(height: 6),
          Text(
            label,
            style: TextStyle(fontSize: 11, color: Colors.grey[600], fontWeight: FontWeight.w500),
          ),
          SizedBox(height: 2),
          Text(
            value,
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: color),
          ),
        ],
      ),
    );
  }
  
  Widget _buildTimeInfo({required IconData icon, required String label, required DateTime? time, required Color color}) {
    return Row(
      children: [
        Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, size: 20, color: color),
        ),
        SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(fontSize: 12, color: Colors.grey[600], fontWeight: FontWeight.w500),
              ),
              Text(
                time != null ? formatTime(time) : "--:--",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: color),
              ),
            ],
          ),
        ),
      ],
    );
  }
}