package com.example.route_planner_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
